from stegano import lsb
secret = lsb.hide("./submit.png", "World")
secret.save("./secret.png")

